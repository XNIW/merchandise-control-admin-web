set statement_timeout='20s';
select public.pos_catalog_import_scope_v1(p_shop_device_id=>'30000000-0000-4000-8000-000000000094',p_shop_id=>'10000000-0000-4000-8000-000000000094');
