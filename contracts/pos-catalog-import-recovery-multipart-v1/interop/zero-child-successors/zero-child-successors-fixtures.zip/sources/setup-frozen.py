import datetime, hashlib, json, pathlib, subprocess
P=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(__file__).resolve().parent
DB='pos_interop_current_zero_child20261010'
CONTAINER='cmc-pos-multipart-20261009-0055'
PIN='bf274d3254701d7343c98ba4666b6863b3153f8a4389ef1a0af04827811e68e0'
MODEL=P/'postgres-interop/minimal-dependencies.sql'
BASE=P/'admin-loader-snapshot-4b7965d9/supabase/migrations'
FILES=[MODEL]+[BASE/name for name in ['20260705120000_task_094_pos_catalog_import_sync.sql','20260706120000_task_094_pos_catalog_import_apply_rpc.sql','20260706143000_task_094_pos_catalog_import_ack_replay.sql','20261008194809_pos_catalog_import_receipt_and_retirement.sql','20261008200355_pos_catalog_import_linked_correction.sql']]+[P/'ddl-frozen-bf274d32.sql']
utc=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
r={'startedUTC':utc(),'actor':'/root/interop_finish','database':DB,'scope':'Frozen bf fixture setup on a fresh owned isolated DB, synthetic dependency/authority model, no candidate RPC/economic invocation or resource/runtime qualification','sqlPath':str(FILES[-1]),'sqlSha256':PIN,'loaded':[],'result':'IN_PROGRESS','candidateFunctionInvocations':0}
try:
 assert sha(FILES[-1].read_bytes())==PIN
 obj=json.loads(subprocess.run(['docker','inspect',CONTAINER],capture_output=True,text=True,check=True).stdout)[0]
 assert obj['Id']=='e181f0f4f8ef53ebe2331c8743c7d4726f414c1ab3341b9e9b049a62332fd06e' and obj['State']['Running'] and obj['HostConfig']['NetworkMode']=='none' and not obj['HostConfig']['Binds'] and not obj['HostConfig']['PortBindings']
 r['containerId']=obj['Id'];r['noNetworkNoPortsNoHostVolumes']=True
 creation=subprocess.run(['docker','exec',CONTAINER,'psql','-X','-U','postgres','-d','postgres','-v','ON_ERROR_STOP=1','-c',f'create database {DB} template template0;'],capture_output=True,text=True,timeout=60)
 (OUT/'create.stdout.txt').write_text(creation.stdout);(OUT/'create.stderr.txt').write_text(creation.stderr);creation.check_returncode();r['createdOwnDatabase']=True
 for index,path in enumerate(FILES):
  data=path.read_bytes(); pin=sha(data)
  cmd=['docker','exec','-i',CONTAINER,'psql','-X','-U','postgres','-d',DB,'-v','ON_ERROR_STOP=1']
  proc=subprocess.run(cmd,input=data,capture_output=True,timeout=60)
  (OUT/f'{index:02}-{path.name}.stdout.txt').write_bytes(proc.stdout);(OUT/f'{index:02}-{path.name}.stderr.txt').write_bytes(proc.stderr)
  r['loaded'].append({'path':str(path),'sha256':pin,'exitCode':proc.returncode,'sourceUnchanged':sha(path.read_bytes())==pin})
  if proc.returncode:
   r['result']='FAIL_SQL_COMPILE_LOAD';r['failedPath']=str(path);r['error']=proc.stderr.decode(errors='replace');break
 else:r['result']='PASS_FROZEN_MODEL_SETUP'
except Exception as e:
 r['result']='BLOCKED_EXECUTION' if r['result']=='IN_PROGRESS' else r['result'];r['error']=str(e)
finally:
 r['endedUTC']=utc();(OUT/'receipt.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'result':r['result'],'database':DB,'loaded':len(r['loaded']),'error':r.get('error'),'receiptSha256':sha((OUT/'receipt.json').read_bytes())}))
