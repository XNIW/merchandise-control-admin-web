-- TASK-094 large-original recovery. Source/local only until separately approved.
-- Existing 1000-row apply and masked correction implementations remain intact.
begin;

create table app_private.pos_catalog_import_recovery_uploads (
  shop_id uuid not null,shop_device_id uuid not null,upload_id uuid not null,
  mode text not null check(mode in ('original','plan')),
  manifest jsonb not null check(jsonb_typeof(manifest)='object'),
  manifest_hash text not null check(manifest_hash ~ '^sha256:[0-9a-f]{64}$'),
  raw_hash text not null check(raw_hash ~ '^sha256:[0-9a-f]{64}$'),
  total_bytes integer not null check(total_bytes between 1 and 33554432),
  normalized_request jsonb,canonical_hash text,client_import_id text,idempotency_key text,
  declared_hash text,original_schema text,item_count integer,
  created_at timestamptz not null default clock_timestamp(),verified_at timestamptz,
  primary key(shop_id,shop_device_id,upload_id),
  check(canonical_hash is null or canonical_hash ~ '^sha256:[0-9a-f]{64}$'),
  check(item_count is null or item_count between 1 and 60000)
);
create table app_private.pos_catalog_import_recovery_upload_parts (
  shop_id uuid not null,shop_device_id uuid not null,upload_id uuid not null,
  part_index integer not null check(part_index between 0 and 127),
  raw_bytes bytea not null check(octet_length(raw_bytes) between 1 and 262144),
  primary key(shop_id,shop_device_id,upload_id,part_index),
  foreign key(shop_id,shop_device_id,upload_id) references app_private.pos_catalog_import_recovery_uploads
);
create table app_private.pos_catalog_import_recovery_plans (
  shop_id uuid not null,shop_device_id uuid not null,plan_id uuid not null,
  original_id uuid not null,original_client_import_id text not null,original_idempotency_key text not null,original_canonical_hash text not null,
  predecessor_plan_id uuid,plan_hash text not null check(plan_hash ~ '^sha256:[0-9a-f]{64}$'),
  mode text not null check(mode in ('replacement','correction')),
  coverage jsonb not null check(jsonb_typeof(coverage)='array'),
  item_count integer not null check(item_count between 0 and 60000),
  part_count integer not null check(part_count between 0 and 128),
  created_at timestamptz not null default clock_timestamp(),
  primary key(shop_id,shop_device_id,plan_id),
  foreign key(shop_id,shop_device_id,original_id) references app_private.pos_catalog_import_recovery_uploads,
  foreign key(shop_id,shop_device_id,predecessor_plan_id) references app_private.pos_catalog_import_recovery_plans
);
create unique index pos_import_recovery_one_initial_plan on app_private.pos_catalog_import_recovery_plans
  (shop_id,shop_device_id,original_client_import_id,original_idempotency_key,original_canonical_hash) where predecessor_plan_id is null;
create unique index pos_import_recovery_one_successor on app_private.pos_catalog_import_recovery_plans
  (shop_id,shop_device_id,predecessor_plan_id) where predecessor_plan_id is not null;
create table app_private.pos_catalog_import_recovery_plan_parts (
  shop_id uuid not null,shop_device_id uuid not null,plan_id uuid not null,
  part_index integer not null check(part_index between 0 and 127),
  child jsonb not null check(jsonb_typeof(child)='object'),
  ack_response jsonb,receipt_hash text,
  primary key(shop_id,shop_device_id,plan_id,part_index),
  foreign key(shop_id,shop_device_id,plan_id) references app_private.pos_catalog_import_recovery_plans,
  check(receipt_hash is null or receipt_hash ~ '^sha256:[0-9a-f]{64}$')
);
alter table app_private.pos_catalog_import_recovery_uploads enable row level security;
alter table app_private.pos_catalog_import_recovery_uploads force row level security;
alter table app_private.pos_catalog_import_recovery_upload_parts enable row level security;
alter table app_private.pos_catalog_import_recovery_upload_parts force row level security;
alter table app_private.pos_catalog_import_recovery_plans enable row level security;
alter table app_private.pos_catalog_import_recovery_plans force row level security;
alter table app_private.pos_catalog_import_recovery_plan_parts enable row level security;
alter table app_private.pos_catalog_import_recovery_plan_parts force row level security;
revoke all on app_private.pos_catalog_import_recovery_uploads,app_private.pos_catalog_import_recovery_upload_parts,
  app_private.pos_catalog_import_recovery_plans,app_private.pos_catalog_import_recovery_plan_parts from public,anon,authenticated,service_role;

-- Complete durable ACK validation stays in PostgreSQL. Public pages and internal
-- contributor projections never transfer a whole large ACK to the Worker.
create function app_private.pos_catalog_import_recovery_ack_valid_v1(
  p_schema text,p_normalized jsonb,p_receipt jsonb
) returns boolean language plpgsql immutable
set search_path=public,app_private,extensions,pg_temp as $$
declare
  v_changed integer;v_prices integer;v_uuid text:='^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$';
begin
  if p_schema is null or p_schema not in ('pos-catalog-import-v1','pos-catalog-import-correction-v1')
    or jsonb_typeof(p_normalized->'items') is distinct from 'array'
    or jsonb_typeof(p_receipt) is distinct from 'object'
    or p_receipt->'ok' is distinct from 'true'::jsonb or coalesce(p_receipt->>'status','') not in('accepted','duplicate','idempotent')
    or coalesce(p_receipt->>'batchId','') !~ v_uuid
    or jsonb_typeof(p_receipt->'summary') is distinct from 'object'
    or jsonb_typeof(p_receipt->'items') is distinct from 'array'
    or jsonb_typeof(p_receipt->'remoteProductIds') is distinct from 'array'
    or jsonb_typeof(p_receipt->'remotePriceIds') is distinct from 'array' then return false;end if;
  if jsonb_array_length(p_normalized->'items')<>jsonb_array_length(p_receipt->'items')
    or (select count(distinct value->>'clientItemId') from jsonb_array_elements(p_receipt->'items'))<>jsonb_array_length(p_receipt->'items')
    or (select count(distinct value->>'clientItemId') from jsonb_array_elements(p_receipt->'remoteProductIds'))<>jsonb_array_length(p_receipt->'remoteProductIds')
    or (select count(distinct value->>'remoteProductId') from jsonb_array_elements(p_receipt->'remoteProductIds'))<>jsonb_array_length(p_receipt->'remoteProductIds')
    or (select count(distinct (value->>'clientItemId',value->>'priceType')) from jsonb_array_elements(p_receipt->'remotePriceIds'))<>jsonb_array_length(p_receipt->'remotePriceIds')
    or (select count(distinct value->>'remotePriceId') from jsonb_array_elements(p_receipt->'remotePriceIds'))<>jsonb_array_length(p_receipt->'remotePriceIds') then return false;end if;
  select count(*) into v_changed from jsonb_array_elements(p_normalized->'items') item
    where p_schema='pos-catalog-import-correction-v1' or item->>'changeKind' in('new','updated');
  if p_receipt->'summary'->'acceptedItemCount' is distinct from to_jsonb(case when p_receipt->>'status'='accepted' then v_changed else 0 end)
    or p_receipt->'summary'->'duplicateItemCount' is distinct from to_jsonb(case when p_receipt->>'status'='accepted' then 0 else v_changed end)
    or p_receipt->'summary'->'productCount' is distinct from to_jsonb(v_changed)
    or (p_receipt->>'status'='accepted' and jsonb_array_length(p_receipt->'remoteProductIds')<>v_changed)
    or jsonb_array_length(p_receipt->'remoteProductIds')>jsonb_array_length(p_normalized->'items') then return false;end if;

  if p_schema='pos-catalog-import-v1' then
    -- Historical persisted ACKs can be duplicate/idempotent after v1 -> v2
    -- replay. Preserve the existing parser's exact summary/map/status rules.
    if exists(with expected as materialized(select value item from jsonb_array_elements(p_normalized->'items')),
      products as materialized(select value mapping from jsonb_array_elements(p_receipt->'remoteProductIds')),
      prices as materialized(select value price from jsonb_array_elements(p_receipt->'remotePriceIds'))
      select 1 from jsonb_array_elements(p_receipt->'items') response
      left join expected on expected.item->>'clientItemId'=response->>'clientItemId'
      left join products on products.mapping->>'clientItemId'=response->>'clientItemId'
      left join prices chosen on chosen.price->>'clientItemId'=response->>'clientItemId' and chosen.price->>'priceType'=
        case when expected.item->'retailPrice' is distinct from 'null'::jsonb then 'retail' else 'purchase' end
      left join prices selected on selected.price->>'clientItemId'=response->>'clientItemId' and selected.price->>'priceType'=response->>'priceType'
      where expected.item is null or response->>'barcode' is distinct from expected.item->>'barcode'
        or not(coalesce(response->>'status','')=case when expected.item->>'changeKind' in('new','updated') then 'accepted' else 'skipped' end
          or (p_receipt->>'status'<>'accepted' and response->>'status'='duplicate'))
        or (coalesce(response->>'remoteProductId','')<>'' and response->>'remoteProductId' !~ v_uuid)
        or (coalesce(response->>'remotePriceId','')<>'' and response->>'remotePriceId' !~ v_uuid)
        or case when expected.item->>'changeKind' in('new','updated') then
          products.mapping is null or response->>'remoteProductId' is distinct from products.mapping->>'remoteProductId'
          or case when expected.item->'retailPrice' is distinct from 'null'::jsonb then
            response->>'priceType' is distinct from 'retail' or response->>'remotePriceId' is distinct from chosen.price->>'remotePriceId' or chosen.price is null
          when expected.item->'purchasePrice' is distinct from 'null'::jsonb then
            response->>'priceType' is distinct from 'purchase' or response->>'remotePriceId' is distinct from chosen.price->>'remotePriceId' or chosen.price is null
          else coalesce(response->>'priceType','')<>'' or coalesce(response->>'remotePriceId','')<>'' end
        when p_receipt->>'status'='accepted' then
          coalesce(response->>'remoteProductId','')<>'' or coalesce(response->>'remotePriceId','')<>'' or coalesce(response->>'priceType','')<>''
        else
          ((coalesce(response->>'remoteProductId','')<>'' or products.mapping is not null) and response->>'remoteProductId' is distinct from products.mapping->>'remoteProductId')
          or ((coalesce(response->>'remotePriceId','')<>'' or coalesce(response->>'priceType','')<>'') and
            (selected.price is null or response->>'remotePriceId' is distinct from selected.price->>'remotePriceId')) end) then return false;end if;
    if exists(select 1 from jsonb_array_elements(p_receipt->'remoteProductIds') mapping
      left join jsonb_array_elements(p_normalized->'items') item on item->>'clientItemId'=mapping->>'clientItemId'
      where item is null or (p_receipt->>'status'='accepted' and item->>'changeKind' not in('new','updated'))
        or mapping->>'barcode' is distinct from item->>'barcode' or coalesce(mapping->>'remoteProductId','') !~ v_uuid) then return false;end if;
    if exists(select 1 from jsonb_array_elements(p_normalized->'items') item
      left join jsonb_array_elements(p_receipt->'remoteProductIds') mapping on mapping->>'clientItemId'=item->>'clientItemId'
      where item->>'changeKind' in('new','updated') and mapping is null) then return false;end if;
    select coalesce(sum((item->'purchasePrice' is distinct from 'null'::jsonb)::integer+(item->'retailPrice' is distinct from 'null'::jsonb)::integer),0)
      into v_prices from jsonb_array_elements(p_normalized->'items') item where item->>'changeKind' in('new','updated');
    if (p_receipt->>'status'='accepted' and v_prices<>jsonb_array_length(p_receipt->'remotePriceIds')) or exists(
      select 1 from jsonb_array_elements(p_receipt->'remotePriceIds') price
      left join jsonb_array_elements(p_normalized->'items') item on item->>'clientItemId'=price->>'clientItemId'
      left join jsonb_array_elements(p_receipt->'remoteProductIds') mapping on mapping->>'clientItemId'=price->>'clientItemId'
      where item is null or (p_receipt->>'status'='accepted' and item->>'changeKind' not in('new','updated'))
        or price->>'barcode' is distinct from item->>'barcode' or coalesce(price->>'remotePriceId','') !~ v_uuid
        or price->>'remoteProductId' is distinct from mapping->>'remoteProductId' or mapping is null
        or case price->>'priceType' when 'purchase' then item->'purchasePrice' is not distinct from 'null'::jsonb
          when 'retail' then item->'retailPrice' is not distinct from 'null'::jsonb else true end) then return false;end if;
    if exists(with prices as materialized(select value price from jsonb_array_elements(p_receipt->'remotePriceIds'))
      select 1 from jsonb_array_elements(p_normalized->'items') item cross join (values('retail','retailPrice'),('purchase','purchasePrice')) required(kind,field)
      left join prices on prices.price->>'clientItemId'=item->>'clientItemId' and prices.price->>'priceType'=required.kind
      where item->>'changeKind' in('new','updated') and item->required.field is distinct from 'null'::jsonb and prices.price is null) then return false;end if;
  else
    if p_receipt->>'status'<>'accepted' then return false;end if;
    -- Correction barcodes can be renamed remotely. Product identity, revision,
    -- every mask price ACK/no-effect proof and exact included base value bind it.
    if exists(select 1 from jsonb_array_elements(p_receipt->'items') response
      left join jsonb_array_elements(p_normalized->'items') item on item->>'clientItemId'=response->>'clientItemId'
      where item is null or response->>'status' is distinct from 'accepted'
        or response->>'remoteProductId' is distinct from item->>'remoteProductId'
        or coalesce(response->>'authoritativeRevision','') !~ '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}[.][0-9]{6}Z$'
        or jsonb_typeof(response->'unchangedFields') is distinct from 'array'
        or (select count(distinct field) from jsonb_array_elements_text(response->'unchangedFields') field)<>jsonb_array_length(response->'unchangedFields')
        or exists(select 1 from jsonb_array_elements_text(response->'unchangedFields') field
          where field not in('retailPrice','purchasePrice') or not(item->'fieldMask' ? field)
            or item->'changes'->field is distinct from item->'baseSnapshot'->field)) then return false;end if;
    if exists(select 1 from jsonb_array_elements(p_receipt->'remoteProductIds') mapping
      left join jsonb_array_elements(p_normalized->'items') item on item->>'clientItemId'=mapping->>'clientItemId'
      left join jsonb_array_elements(p_receipt->'items') response on response->>'clientItemId'=mapping->>'clientItemId'
      where item is null or mapping->>'remoteProductId' is distinct from item->>'remoteProductId'
        or mapping->>'authoritativeRevision' is distinct from response->>'authoritativeRevision') then return false;end if;
    if exists(select 1 from jsonb_array_elements(p_receipt->'remotePriceIds') price
      left join jsonb_array_elements(p_normalized->'items') item on item->>'clientItemId'=price->>'clientItemId'
      where item is null or coalesce(price->>'remotePriceId','') !~ v_uuid
        or price->>'remoteProductId' is distinct from item->>'remoteProductId'
        or not(item->'fieldMask' ? case price->>'priceType' when 'retail' then 'retailPrice' when 'purchase' then 'purchasePrice' else '__invalid__' end)) then return false;end if;
    if exists(with prices as materialized(select value price from jsonb_array_elements(p_receipt->'remotePriceIds'))
      select 1 from jsonb_array_elements(p_normalized->'items') item
      join jsonb_array_elements(p_receipt->'items') response on response->>'clientItemId'=item->>'clientItemId'
      cross join lateral jsonb_array_elements_text(item->'fieldMask') field
      left join prices on prices.price->>'clientItemId'=item->>'clientItemId' and prices.price->>'priceType'=
        case field when 'retailPrice' then 'retail' else 'purchase' end
      where field in('retailPrice','purchasePrice') and
        (response->'unchangedFields' ? field)=(prices.price is not null)) then return false;end if;
  end if;
  return true;
exception when invalid_text_representation or invalid_parameter_value or numeric_value_out_of_range then return false;
end;
$$;
revoke all on function app_private.pos_catalog_import_recovery_ack_valid_v1(text,jsonb,jsonb) from public,anon,authenticated,service_role;

-- A finite linear chain of immutable scoped plans. Handles from unrelated
-- roots/branches cannot supply economic contributions to a successor.
create function app_private.pos_catalog_import_recovery_ancestor_v1(p_shop uuid,p_device uuid,p_start uuid,p_target uuid)
returns boolean language sql stable set search_path=public,app_private,extensions,pg_temp as $$
  with recursive ancestors as (
    select plan_id,predecessor_plan_id,1 depth,array[plan_id] visited from app_private.pos_catalog_import_recovery_plans
      where shop_id=p_shop and shop_device_id=p_device and plan_id=p_start
    union all
    select parent.plan_id,parent.predecessor_plan_id,child.depth+1,child.visited||parent.plan_id
      from ancestors child join app_private.pos_catalog_import_recovery_plans parent on parent.shop_id=p_shop and parent.shop_device_id=p_device
        and parent.plan_id=child.predecessor_plan_id where child.depth<128 and not(parent.plan_id=any(child.visited))
  ) select exists(select 1 from ancestors where plan_id=p_target);
$$;
revoke all on function app_private.pos_catalog_import_recovery_ancestor_v1(uuid,uuid,uuid,uuid) from public,anon,authenticated,service_role;

create function public.pos_catalog_import_recovery_v1(
  p_shop_id uuid,p_shop_device_id uuid,p_staff_id uuid,p_pos_session_id uuid,p_owner_user_id uuid,
  p_action text,p_payload jsonb
) returns jsonb language plpgsql volatile security definer
set search_path=public,app_private,extensions,pg_temp as $$
declare
 v_auth text;v_upload app_private.pos_catalog_import_recovery_uploads%rowtype;
 v_original app_private.pos_catalog_import_recovery_uploads%rowtype;
 v_plan app_private.pos_catalog_import_recovery_plans%rowtype;
 v_predecessor app_private.pos_catalog_import_recovery_plans%rowtype;
 v_part app_private.pos_catalog_import_recovery_plan_parts%rowtype;
 v_id uuid;v_original_id uuid;v_predecessor_id uuid;v_index integer;v_bytes bytea;v_all_bytes bytea;
 v_manifest jsonb;v_expected jsonb;v_result jsonb;v_receipt jsonb;v_child jsonb;v_entry jsonb;
 v_hash text;v_count integer;v_total integer;v_offset integer;v_limit integer;v_complete boolean;
 v_binding jsonb:=jsonb_build_object('ok',true,'shopId',p_shop_id,'shopDeviceId',p_shop_device_id);
begin
 if p_action not in('upload','read-upload','finalize','read-original','read-receipt','read-plan-part','receipt','retire','plan','apply','receipt-page')
   or jsonb_typeof(p_payload) is distinct from 'object' then
   return jsonb_build_object('ok',false,'code','validation_failed');
 end if;
 v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
 if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;

 if p_action in('upload','read-upload','finalize') then
   v_id:=(p_payload->>'uploadId')::uuid;
   perform pg_advisory_xact_lock(hashtext('pos-import-upload:'||p_shop_id::text||':'||p_shop_device_id::text),hashtext(v_id::text));
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   if p_action='upload' then
     v_manifest:=p_payload->'manifest';v_index:=(p_payload->>'partIndex')::integer;
     if jsonb_typeof(v_manifest) is distinct from 'object' or v_manifest->>'mode' not in('original','plan')
       or coalesce(v_manifest->>'rawSha256','') !~ '^sha256:[0-9a-f]{64}$'
       or coalesce(p_payload->>'manifestSha256','') !~ '^sha256:[0-9a-f]{64}$'
       or jsonb_typeof(v_manifest->'parts') is distinct from 'array' then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     v_total:=(v_manifest->>'totalByteLength')::integer;
     if v_total not between 1 and 33554432 or jsonb_array_length(v_manifest->'parts') not between 1 and 128
       or v_index not between 0 and jsonb_array_length(v_manifest->'parts')-1 then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     v_count:=0;
     for v_entry in select value from jsonb_array_elements(v_manifest->'parts') loop
       if (v_entry->>'index')::integer<>v_count or (v_entry->>'byteLength')::integer not between 1 and 262144
         or coalesce(v_entry->>'sha256','') !~ '^sha256:[0-9a-f]{64}$' then
         return jsonb_build_object('ok',false,'code','validation_failed');end if;
       v_count:=v_count+1;
     end loop;
     if (select sum((part->>'byteLength')::integer) from jsonb_array_elements(v_manifest->'parts') part)<>v_total then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     v_bytes:=decode(p_payload->>'contentBase64','base64');v_expected:=v_manifest->'parts'->v_index;
     if octet_length(v_bytes)<>(v_expected->>'byteLength')::integer
       or 'sha256:'||encode(extensions.digest(v_bytes,'sha256'),'hex')<>v_expected->>'sha256' then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     insert into app_private.pos_catalog_import_recovery_uploads(shop_id,shop_device_id,upload_id,mode,manifest,manifest_hash,raw_hash,total_bytes)
     values(p_shop_id,p_shop_device_id,v_id,v_manifest->>'mode',v_manifest,p_payload->>'manifestSha256',v_manifest->>'rawSha256',v_total)
     on conflict do nothing;
   end if;
   select * into v_upload from app_private.pos_catalog_import_recovery_uploads
     where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id for update;
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   if v_upload.upload_id is null then return jsonb_build_object('ok',false,'code','not_found');end if;
   if p_action='upload' then
     if v_upload.manifest is distinct from v_manifest or v_upload.manifest_hash is distinct from p_payload->>'manifestSha256' then
       return v_binding||jsonb_build_object('status','conflict','reason','upload_manifest_conflict');end if;
     select raw_bytes into v_all_bytes from app_private.pos_catalog_import_recovery_upload_parts
       where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id and part_index=v_index;
     if found and v_all_bytes<>v_bytes then return v_binding||jsonb_build_object('status','conflict','reason','upload_part_conflict');end if;
     insert into app_private.pos_catalog_import_recovery_upload_parts values(p_shop_id,p_shop_device_id,v_id,v_index,v_bytes) on conflict do nothing;
     return v_binding||jsonb_build_object('status','uploaded','uploadId',v_id,'partIndex',v_index,'manifestSha256',v_upload.manifest_hash);
   end if;
   select count(*),string_agg(raw_bytes,''::bytea order by part_index) into v_count,v_all_bytes
     from app_private.pos_catalog_import_recovery_upload_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id;
   if v_count<>jsonb_array_length(v_upload.manifest->'parts') or octet_length(v_all_bytes)<>v_upload.total_bytes
     or 'sha256:'||encode(extensions.digest(v_all_bytes,'sha256'),'hex')<>v_upload.raw_hash then
     return v_binding||jsonb_build_object('status','conflict','reason','upload_incomplete');end if;
   if p_action='read-upload' then
     return v_binding||jsonb_build_object('status','uploaded','uploadId',v_id,'manifest',v_upload.manifest,'manifestSha256',v_upload.manifest_hash,
       'parts',(select jsonb_agg(jsonb_build_object('index',part_index,'contentBase64',replace(encode(raw_bytes,'base64'),E'\n','')) order by part_index)
         from app_private.pos_catalog_import_recovery_upload_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id));
   end if;
   if v_upload.mode<>'original' or v_upload.manifest_hash is distinct from p_payload->>'manifestSha256'
     or v_upload.raw_hash is distinct from p_payload->>'rawSha256'
     or coalesce(p_payload->>'canonicalPayloadHash','') !~ '^sha256:[0-9a-f]{64}$'
     or jsonb_typeof(p_payload->'normalizedRequest') is distinct from 'object'
     or coalesce(p_payload->>'originalSchemaVersion','') not in('pos-catalog-import-v1','pos-catalog-import-correction-v1')
     or length(p_payload->>'clientImportId') not between 1 and 200 or length(p_payload->>'idempotencyKey') not between 1 and 200
     or (p_payload->>'itemCount')::integer not between 1 and 60000 then
     return jsonb_build_object('ok',false,'code','validation_failed');end if;
   if v_upload.verified_at is not null and (v_upload.normalized_request is distinct from p_payload->'normalizedRequest'
     or v_upload.canonical_hash is distinct from p_payload->>'canonicalPayloadHash') then
     return v_binding||jsonb_build_object('status','conflict','reason','verified_original_conflict');end if;
   update app_private.pos_catalog_import_recovery_uploads set normalized_request=p_payload->'normalizedRequest',canonical_hash=p_payload->>'canonicalPayloadHash',
     client_import_id=p_payload->>'clientImportId',idempotency_key=p_payload->>'idempotencyKey',declared_hash=p_payload->>'payloadHash',
     original_schema=p_payload->>'originalSchemaVersion',item_count=(p_payload->>'itemCount')::integer,verified_at=coalesce(verified_at,clock_timestamp())
     where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id;
   return v_binding||jsonb_build_object('status','verified','verifiedOriginalId',v_id,'originalSchemaVersion',p_payload->>'originalSchemaVersion',
     'clientImportId',p_payload->>'clientImportId','idempotencyKey',p_payload->>'idempotencyKey','payloadHash',p_payload->>'payloadHash',
     'canonicalPayloadHash',p_payload->>'canonicalPayloadHash','rawSha256',v_upload.raw_hash,'itemCount',(p_payload->>'itemCount')::integer);
 end if;

 if p_action in('read-original','read-receipt') or (p_action in('receipt','retire','receipt-page') and p_payload?'verifiedOriginalId' and not(p_payload?'planId')) then
   v_id:=(p_payload->>'verifiedOriginalId')::uuid;
   select * into v_upload from app_private.pos_catalog_import_recovery_uploads
     where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id and verified_at is not null;
   if not found then return jsonb_build_object('ok',false,'code','not_found');end if;
   if p_action='read-original' then return v_binding||jsonb_build_object('status','verified','verifiedOriginalId',v_id,
     'normalizedRequest',v_upload.normalized_request,'originalSchemaVersion',v_upload.original_schema,
     'clientImportId',v_upload.client_import_id,'idempotencyKey',v_upload.idempotency_key,'payloadHash',v_upload.declared_hash,
     'canonicalPayloadHash',v_upload.canonical_hash,'itemCount',v_upload.item_count);end if;
   if p_action='retire' then
     v_result:=public.pos_catalog_import_retire_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
       v_upload.client_import_id,v_upload.idempotency_key,v_upload.canonical_hash);
   else
     v_result:=public.pos_catalog_import_receipt_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
       v_upload.client_import_id,v_upload.idempotency_key,v_upload.canonical_hash);
   end if;
   if v_result->>'ok' is distinct from 'true' then return v_result;end if;
   if v_result->>'status'<>'accepted' then return v_result||jsonb_build_object('verifiedOriginalId',v_id,'originalSchemaVersion',v_upload.original_schema,
     'payloadHash',v_upload.declared_hash,'canonicalPayloadHash',v_upload.canonical_hash);end if;
   v_receipt:=v_result->'receipt';
   if not app_private.pos_catalog_import_recovery_ack_valid_v1(v_upload.original_schema,v_upload.normalized_request,v_receipt) then
     return v_binding||jsonb_build_object('status','conflict','reason','receipt_unavailable');end if;
   if p_action='read-receipt' then
     if p_payload?'clientItemIds' and (jsonb_typeof(p_payload->'clientItemIds') is distinct from 'array'
       or jsonb_array_length(p_payload->'clientItemIds') not between 1 and 1000) then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     return (v_result-'receipt'-'currentProductSnapshots')||jsonb_build_object('verifiedOriginalId',v_id,'receiptValidated',true,
       'totalItemCount',jsonb_array_length(v_receipt->'items'),'originalSchemaVersion',v_upload.original_schema,
       'rawItems',(select coalesce(jsonb_agg(item),'[]'::jsonb) from jsonb_array_elements(coalesce(v_upload.normalized_request->'rawItems','[]'::jsonb)) item
         where p_payload->'clientItemIds' ? (item->>'clientItemId')),
       'receiptSha256','sha256:'||encode(extensions.digest(v_receipt::text,'sha256'),'hex'),
       'remoteProductIds',(select coalesce(jsonb_agg(mapping),'[]'::jsonb) from jsonb_array_elements(v_receipt->'remoteProductIds') mapping
         where p_payload->'clientItemIds' ? (mapping->>'clientItemId')));
   end if;
   v_result:=v_result||jsonb_build_object('verifiedOriginalId',v_id,'originalSchemaVersion',v_upload.original_schema,
     'payloadHash',v_upload.declared_hash,'canonicalPayloadHash',v_upload.canonical_hash);
 end if;

 if p_action='read-plan-part' or (p_action in('receipt','retire') and p_payload?'planId') then
   v_id:=(p_payload->>'planId')::uuid;v_index:=(p_payload->>'partIndex')::integer;
   select * into v_plan from app_private.pos_catalog_import_recovery_plans
     where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id;
   if not found then return jsonb_build_object('ok',false,'code','not_found');end if;
   select * into v_original from app_private.pos_catalog_import_recovery_uploads where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_plan.original_id;
   perform pg_advisory_xact_lock(hashtext('pos-import-recovery-root:'||p_shop_id::text||':'||p_shop_device_id::text),
     hashtext(v_original.client_import_id||':'||v_original.idempotency_key||':'||v_original.canonical_hash));
   perform pg_advisory_xact_lock(hashtext('pos-import-plan:'||p_shop_id::text||':'||p_shop_device_id::text),hashtext(v_id::text));
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   select * into v_part from app_private.pos_catalog_import_recovery_plan_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id and part_index=v_index;
   if not found then return jsonb_build_object('ok',false,'code','not_found');end if;
   v_child:=v_part.child;
   if p_action='read-plan-part' then
     select * into v_upload from app_private.pos_catalog_import_recovery_uploads where shop_id=p_shop_id and shop_device_id=p_shop_device_id
       and upload_id=(p_payload->>'verifiedOriginalId')::uuid and verified_at is not null;
     if not found or v_upload.client_import_id is distinct from v_original.client_import_id or v_upload.idempotency_key is distinct from v_original.idempotency_key
       or v_upload.canonical_hash is distinct from v_original.canonical_hash or jsonb_typeof(p_payload->'clientItemIds') is distinct from 'array'
       or jsonb_array_length(p_payload->'clientItemIds') not between 1 and 1000
       or not app_private.pos_catalog_import_recovery_ancestor_v1(p_shop_id,p_shop_device_id,(p_payload->>'predecessorPlanId')::uuid,v_id) then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     v_receipt:=v_part.ack_response;
     if v_receipt is null or not app_private.pos_catalog_import_recovery_ack_valid_v1(
       case v_child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,v_child,v_receipt) then
       return v_binding||jsonb_build_object('status','conflict','reason','contributor_unavailable');end if;
     return v_binding||jsonb_build_object('status','accepted','receiptValidated',true,'planId',v_id,'partIndex',v_index,
       'canonicalPayloadHash',v_child->>'payloadHash','receiptSha256','sha256:'||encode(extensions.digest(v_receipt::text,'sha256'),'hex'),
       'items',(select coalesce(jsonb_agg(jsonb_build_object('clientItemId',item->>'clientItemId',
         'originalClientItemId',(select entry->>'clientItemId' from jsonb_array_elements(v_plan.coverage) entry where entry->>'kind'='child' and (entry->>'partIndex')::integer=v_index and entry->>'childClientItemId'=item->>'clientItemId'),
         'barcode',case when v_child->>'kind'='ordinary' then item->>'barcode' else response->>'barcode' end,
         'itemStatus',response->>'status','economic',v_child->>'kind'='correction' or item->>'changeKind' in('new','updated'),
         'remoteProductId',case when v_child->>'kind'='correction' or item->>'changeKind' in('new','updated') then mapping->>'remoteProductId' else null end)), '[]'::jsonb)
         from jsonb_array_elements(v_child->'items') item
         join jsonb_array_elements(v_receipt->'items') response on response->>'clientItemId'=item->>'clientItemId'
         left join jsonb_array_elements(v_receipt->'remoteProductIds') mapping on mapping->>'clientItemId'=item->>'clientItemId'
         where p_payload->'clientItemIds' ? (item->>'clientItemId')));
   end if;
   if p_action='retire' then v_result:=public.pos_catalog_import_retire_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
     v_child->>'clientImportId',v_child->>'idempotencyKey',v_child->>'payloadHash');
   else v_result:=public.pos_catalog_import_receipt_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
     v_child->>'clientImportId',v_child->>'idempotencyKey',v_child->>'payloadHash');end if;
   if v_result->>'ok' is distinct from 'true' then return v_result;end if;
   v_result:=(v_result-'payloadHash')||jsonb_build_object('planId',v_id,'partIndex',v_index,'originalSchemaVersion',
     case v_child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,
     'payloadHash',v_child->>'declaredPayloadHash','canonicalPayloadHash',v_child->>'payloadHash');
   if v_result->>'status' is distinct from 'accepted' then return v_result;end if;
   v_receipt:=v_result->'receipt';
   if not app_private.pos_catalog_import_recovery_ack_valid_v1(
     case v_child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,v_child,v_receipt) then
     return v_binding||jsonb_build_object('status','conflict','reason','receipt_unavailable');end if;
   if p_action='retire' then
     -- Explicit retirement can discover an ordinary/correction endpoint won.
     -- Adopt only that exact validated durable ACK; never reapply economics.
     if v_part.ack_response is not null and v_part.ack_response is distinct from v_receipt then
       return v_binding||jsonb_build_object('status','conflict','reason','receipt_identity_conflict');end if;
     update app_private.pos_catalog_import_recovery_plan_parts set ack_response=v_receipt,
       receipt_hash='sha256:'||encode(extensions.digest(v_receipt::text,'sha256'),'hex')
       where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id and part_index=v_index and ack_response is null;
   end if;
 end if;

 if p_action='plan' then
   v_id:=(p_payload->>'uploadId')::uuid;
   select * into v_upload from app_private.pos_catalog_import_recovery_uploads where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id for update;
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   if v_upload.upload_id is null or v_upload.mode<>'plan' or v_upload.raw_hash is distinct from p_payload->>'rawSha256'
     or v_upload.manifest_hash is distinct from p_payload->>'manifestSha256' then return jsonb_build_object('ok',false,'code','validation_failed');end if;
   select count(*),string_agg(raw_bytes,''::bytea order by part_index) into v_count,v_all_bytes
     from app_private.pos_catalog_import_recovery_upload_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_id;
   if v_count<>jsonb_array_length(v_upload.manifest->'parts') or 'sha256:'||encode(extensions.digest(v_all_bytes,'sha256'),'hex')<>v_upload.raw_hash then
     return v_binding||jsonb_build_object('status','conflict','reason','upload_incomplete');end if;
   v_expected:=p_payload->'plan';v_original_id:=(v_expected->>'verifiedOriginalId')::uuid;v_id:=(v_expected->>'planId')::uuid;
   select * into v_original from app_private.pos_catalog_import_recovery_uploads where shop_id=p_shop_id and shop_device_id=p_shop_device_id
     and upload_id=v_original_id and verified_at is not null;
   if not found or v_expected->>'mode' not in('replacement','correction') or coalesce(v_expected->>'planCanonicalHash','') !~ '^sha256:[0-9a-f]{64}$'
     or jsonb_typeof(v_expected->'parts') is distinct from 'array' or jsonb_typeof(v_expected->'coverage') is distinct from 'array'
     or jsonb_array_length(v_expected->'parts')>128 then return jsonb_build_object('ok',false,'code','validation_failed');end if;
   perform pg_advisory_xact_lock(hashtext('pos-import-recovery-root:'||p_shop_id::text||':'||p_shop_device_id::text),
     hashtext(v_original.client_import_id||':'||v_original.idempotency_key||':'||v_original.canonical_hash));
   -- Root -> plan -> identity -> row is also the apply/replay order. A replay cannot
   -- hold original locks while waiting for an apply's plan row.
   perform pg_advisory_xact_lock(hashtext('pos-import-plan:'||p_shop_id::text||':'||p_shop_device_id::text),hashtext(v_id::text));
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   v_result:=public.pos_catalog_import_receipt_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
     v_original.client_import_id,v_original.idempotency_key,v_original.canonical_hash);
   -- Planning NEVER creates retirement. The only allowed replacement is an
   -- already retired identity, checked below without invoking a mutable RPC.
   -- The caller cannot use a not_found snapshot as permission to apply.
   if v_expected->>'mode'='replacement' and not exists(select 1 from app_private.pos_catalog_import_retirements
     where shop_id=p_shop_id and shop_device_id=p_shop_device_id and client_import_id=v_original.client_import_id
       and idempotency_key=v_original.idempotency_key and payload_hash=v_original.canonical_hash) then
     return v_binding||jsonb_build_object('status','conflict','reason','original_not_retired');end if;
   if v_result->>'ok' is distinct from 'true' then return v_result;end if;
   if v_expected->>'mode'='correction' and (v_result->>'status' is distinct from 'accepted'
     or not app_private.pos_catalog_import_recovery_ack_valid_v1(v_original.original_schema,v_original.normalized_request,v_result->'receipt')) then
     return v_binding||jsonb_build_object('status','conflict','reason','original_receipt_unavailable');end if;
   v_predecessor_id:=null;
   if v_expected?'supersedes' then
     v_predecessor_id:=(v_expected->'supersedes'->>'planId')::uuid;
     if v_predecessor_id=v_id or jsonb_typeof(v_expected->'supersedes'->'retiredChildren') is distinct from 'array' then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
     select * into v_predecessor from app_private.pos_catalog_import_recovery_plans where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_predecessor_id;
     if not found or v_predecessor.mode is distinct from v_expected->>'mode' or v_predecessor.original_client_import_id is distinct from v_original.client_import_id
       or v_predecessor.original_idempotency_key is distinct from v_original.idempotency_key or v_predecessor.original_canonical_hash is distinct from v_original.canonical_hash then
       return v_binding||jsonb_build_object('status','conflict','reason','predecessor_scope_conflict');end if;
     -- The common root lock precedes predecessor/target plan and identity locks.
     perform pg_advisory_xact_lock(hashtext('pos-import-plan:'||p_shop_id::text||':'||p_shop_device_id::text),hashtext(v_predecessor_id::text));
     for v_part in select * from app_private.pos_catalog_import_recovery_plan_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_predecessor_id order by part_index loop
       v_child:=v_part.child;
       if v_part.ack_response is null then
         if not exists(select 1 from jsonb_array_elements(v_expected->'supersedes'->'retiredChildren') retired
           where (retired->>'partIndex')::integer=v_part.part_index and retired->>'canonicalPayloadHash'=v_child->>'payloadHash')
           or not exists(select 1 from app_private.pos_catalog_import_retirements where shop_id=p_shop_id and shop_device_id=p_shop_device_id
             and client_import_id=v_child->>'clientImportId' and idempotency_key=v_child->>'idempotencyKey' and payload_hash=v_child->>'payloadHash') then
           return v_binding||jsonb_build_object('status','conflict','reason','predecessor_child_not_retired');end if;
       elsif not app_private.pos_catalog_import_recovery_ack_valid_v1(
         case v_child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,v_child,v_part.ack_response)
         or exists(select 1 from jsonb_array_elements(v_child->'items') item where not exists(
           select 1 from jsonb_array_elements(v_expected->'coverage') entry where entry->>'kind'='accepted_plan_part'
             and (entry->>'contributorPlanId')::uuid=v_predecessor_id and (entry->>'contributorPartIndex')::integer=v_part.part_index
             and entry->>'contributorClientItemId'=item->>'clientItemId' and exists(select 1 from jsonb_array_elements(v_predecessor.coverage) previous
               where previous->>'kind'='child' and (previous->>'partIndex')::integer=v_part.part_index and previous->>'childClientItemId'=item->>'clientItemId' and previous->>'clientItemId'=entry->>'clientItemId'))) then
         return v_binding||jsonb_build_object('status','conflict','reason','predecessor_ack_not_carried');end if;
     end loop;
     if exists(select 1 from jsonb_array_elements(v_predecessor.coverage) previous where previous->>'kind' in('accepted_plan_part','accepted_contributor')
       and not exists(select 1 from jsonb_array_elements(v_expected->'coverage') current
         where current=previous)) then return v_binding||jsonb_build_object('status','conflict','reason','predecessor_proof_not_carried');end if;
     -- Maximum 128 generations; no silent truncation permits an older proof.
     if exists(with recursive ancestry as (
       select plan_id,predecessor_plan_id,1 depth from app_private.pos_catalog_import_recovery_plans where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_predecessor_id
       union all select parent.plan_id,parent.predecessor_plan_id,child.depth+1 from ancestry child join app_private.pos_catalog_import_recovery_plans parent
         on parent.shop_id=p_shop_id and parent.shop_device_id=p_shop_device_id and parent.plan_id=child.predecessor_plan_id where child.depth<128
       ) select 1 from ancestry where depth=128) then return v_binding||jsonb_build_object('status','conflict','reason','recovery_ancestry_limit');end if;
     if jsonb_array_length(v_expected->'supersedes'->'retiredChildren')<>(select count(*) from app_private.pos_catalog_import_recovery_plan_parts
       where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_predecessor_id and ack_response is null) then
       return v_binding||jsonb_build_object('status','conflict','reason','predecessor_retirement_set_conflict');end if;
   end if;
   if exists(select 1 from app_private.pos_catalog_import_recovery_plans existing where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id<>v_id and
     ((v_predecessor_id is null and predecessor_plan_id is null and original_client_import_id=v_original.client_import_id
        and original_idempotency_key=v_original.idempotency_key and original_canonical_hash=v_original.canonical_hash)
      or (v_predecessor_id is not null and predecessor_plan_id=v_predecessor_id))) then
     return v_binding||jsonb_build_object('status','conflict','reason','recovery_group_fork');end if;
   if jsonb_array_length(v_expected->'coverage')<>v_original.item_count or
     (select count(distinct entry->>'clientItemId') from jsonb_array_elements(v_expected->'coverage') entry)<>v_original.item_count then
     return jsonb_build_object('ok',false,'code','validation_failed');end if;
   -- Expand each immutable row set exactly once. Correlated SRFs here made a
   -- real 5000-row plan spill for minutes without reaching an economic write.
   if (with roots as materialized (
       select item->>'clientItemId' root_id from jsonb_array_elements(v_original.normalized_request->'items') item
     ), coverage as materialized (
       select entry->>'clientItemId' root_id,entry->>'kind' kind,(entry->>'partIndex')::integer part_index,
         entry->>'childClientItemId' child_id from jsonb_array_elements(v_expected->'coverage') entry
     ), children as materialized (
       select child->>'kind' kind,(child->>'index')::integer part_index,item->>'clientItemId' child_id
         from jsonb_array_elements(v_expected->'parts') child cross join lateral jsonb_array_elements(child->'items') item
     ) select
       exists(select 1 from coverage left join roots using(root_id) where roots.root_id is null)
       or exists(select 1 from children left join coverage on coverage.kind='child' and coverage.part_index=children.part_index and coverage.child_id=children.child_id
         group by children.part_index,children.child_id having count(coverage.root_id)<>1)
       or exists(select 1 from coverage left join children on children.part_index=coverage.part_index and children.child_id=coverage.child_id
         where coverage.kind='child' and (children.child_id is null or (children.kind is distinct from 'ordinary' and children.child_id<>coverage.root_id)))) then
     return jsonb_build_object('ok',false,'code','validation_failed');end if;
   for v_entry in select value from jsonb_array_elements(v_expected->'coverage') loop
     if v_entry->>'kind'='accepted_contributor' then
       select * into v_upload from app_private.pos_catalog_import_recovery_uploads where shop_id=p_shop_id and shop_device_id=p_shop_device_id
         and upload_id=(v_entry->>'verifiedContributorId')::uuid and verified_at is not null;
       if not found then return v_binding||jsonb_build_object('status','conflict','reason','contributor_unavailable');end if;
       v_result:=public.pos_catalog_import_receipt_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
         v_upload.client_import_id,v_upload.idempotency_key,v_upload.canonical_hash);
       if v_result->>'ok' is distinct from 'true' or v_result->>'status' is distinct from 'accepted'
         or not app_private.pos_catalog_import_recovery_ack_valid_v1(v_upload.original_schema,v_upload.normalized_request,v_result->'receipt') or 'sha256:'||encode(extensions.digest((v_result->'receipt')::text,'sha256'),'hex') is distinct from v_entry->>'contributorReceiptSha256'
         or not exists(select 1 from jsonb_array_elements(v_result->'receipt'->'remoteProductIds') mapping
           where mapping->>'clientItemId'=v_entry->>'contributorClientItemId') then
         return v_binding||jsonb_build_object('status','conflict','reason','contributor_unavailable');end if;
     elsif v_entry->>'kind'='accepted_plan_part' then
       if v_predecessor_id is null then return jsonb_build_object('ok',false,'code','validation_failed');end if;
       select * into v_part from app_private.pos_catalog_import_recovery_plan_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id
         and plan_id=(v_entry->>'contributorPlanId')::uuid and part_index=(v_entry->>'contributorPartIndex')::integer;
       if not app_private.pos_catalog_import_recovery_ancestor_v1(p_shop_id,p_shop_device_id,v_predecessor_id,(v_entry->>'contributorPlanId')::uuid) then
         return v_binding||jsonb_build_object('status','conflict','reason','predecessor_scope_conflict');end if;
       if not found or v_part.ack_response is null or v_entry->>'contributorCanonicalPayloadHash' is distinct from v_part.child->>'payloadHash'
         or v_entry->>'contributorReceiptSha256' is distinct from 'sha256:'||encode(extensions.digest(v_part.ack_response::text,'sha256'),'hex')
         or not app_private.pos_catalog_import_recovery_ack_valid_v1(
           case v_part.child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,v_part.child,v_part.ack_response)
         or not exists(select 1 from jsonb_array_elements(v_part.child->'items') item
           join jsonb_array_elements(v_part.ack_response->'items') response on response->>'clientItemId'=item->>'clientItemId'
           left join jsonb_array_elements(v_part.ack_response->'remoteProductIds') mapping on mapping->>'clientItemId'=item->>'clientItemId'
           where item->>'clientItemId'=v_entry->>'contributorClientItemId' and response->>'status'=v_entry->>'contributorItemStatus'
             and exists(select 1 from app_private.pos_catalog_import_recovery_plans ancestor, jsonb_array_elements(ancestor.coverage) previous
               where ancestor.shop_id=p_shop_id and ancestor.shop_device_id=p_shop_device_id and ancestor.plan_id=v_part.plan_id
                 and previous->>'kind'='child' and (previous->>'partIndex')::integer=v_part.part_index
                 and previous->>'childClientItemId'=item->>'clientItemId' and previous->>'clientItemId'=v_entry->>'clientItemId')
             and case when v_part.child->>'kind'='correction' or item->>'changeKind' in('new','updated') then
               mapping is not null and mapping->>'remoteProductId'=v_entry->>'contributorRemoteProductId'
             else v_entry->'contributorRemoteProductId'='null'::jsonb end) then
         return v_binding||jsonb_build_object('status','conflict','reason','predecessor_ack_not_carried');end if;
     elsif v_entry->>'kind' not in('child','original_accepted') or (v_entry->>'kind'='original_accepted' and v_expected->>'mode'<>'correction') then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;
   end loop;
   v_count:=0;
   for v_child in select value from jsonb_array_elements(v_expected->'parts') loop
     if (v_child->>'index')::integer<>v_count or jsonb_typeof(v_child->'items') is distinct from 'array'
       or jsonb_array_length(v_child->'items') not between 1 and 1000 or pg_column_size(v_child->'items')>524288 then
       return jsonb_build_object('ok',false,'code','validation_failed');end if;v_count:=v_count+1;
   end loop;
   perform pg_advisory_xact_lock(hashtext('pos-import-plan:'||p_shop_id::text||':'||p_shop_device_id::text),hashtext(v_id::text));
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   insert into app_private.pos_catalog_import_recovery_plans(shop_id,shop_device_id,plan_id,original_id,original_client_import_id,original_idempotency_key,original_canonical_hash,predecessor_plan_id,plan_hash,mode,coverage,item_count,part_count)
     values(p_shop_id,p_shop_device_id,v_id,v_original_id,v_original.client_import_id,v_original.idempotency_key,v_original.canonical_hash,v_predecessor_id,v_expected->>'planCanonicalHash',v_expected->>'mode',v_expected->'coverage',
       (v_expected->>'itemCount')::integer,jsonb_array_length(v_expected->'parts')) on conflict do nothing;
   select * into v_plan from app_private.pos_catalog_import_recovery_plans where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id for update;
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   if v_plan.plan_hash is distinct from v_expected->>'planCanonicalHash' or v_plan.coverage is distinct from v_expected->'coverage' then
     return v_binding||jsonb_build_object('status','conflict','reason','plan_conflict');end if;
   v_count:=0;
   for v_child in select value from jsonb_array_elements(v_expected->'parts') loop
     insert into app_private.pos_catalog_import_recovery_plan_parts(shop_id,shop_device_id,plan_id,part_index,child)
       values(p_shop_id,p_shop_device_id,v_id,v_count,v_child) on conflict do nothing;v_count:=v_count+1;
   end loop;
   return v_binding||jsonb_build_object('status','planned','planId',v_id,'verifiedOriginalId',v_original_id,'planCanonicalHash',v_plan.plan_hash,
     'parentStatus',case when v_plan.part_count=0 then 'complete' else 'partial' end,
     'partCount',v_plan.part_count,'itemCount',v_plan.item_count,'parts',(select coalesce(jsonb_agg(child-'items'-'summary'-'normalized' order by part_index),'[]'::jsonb)
       from app_private.pos_catalog_import_recovery_plan_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id));
 end if;

 if p_action='apply' or (p_action='receipt-page' and p_payload?'planId') then
   v_id:=(p_payload->>'planId')::uuid;v_index:=(p_payload->>'partIndex')::integer;
   select * into v_plan from app_private.pos_catalog_import_recovery_plans where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id;
   if not found then return jsonb_build_object('ok',false,'code','not_found');end if;
   perform pg_advisory_xact_lock(hashtext('pos-import-recovery-root:'||p_shop_id::text||':'||p_shop_device_id::text),
     hashtext(v_plan.original_client_import_id||':'||v_plan.original_idempotency_key||':'||v_plan.original_canonical_hash));
   perform pg_advisory_xact_lock(hashtext('pos-import-plan:'||p_shop_id::text||':'||p_shop_device_id::text),hashtext(v_id::text));
   select * into v_plan from app_private.pos_catalog_import_recovery_plans where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id for update;
   v_auth:=app_private.pos_catalog_import_receipt_authorize_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id);
   if v_auth<>'ok' then return jsonb_build_object('ok',false,'code',v_auth);end if;
   if not found or v_plan.plan_id is null then return jsonb_build_object('ok',false,'code','not_found');end if;
   select * into v_part from app_private.pos_catalog_import_recovery_plan_parts where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id and part_index=v_index;
   if not found then return jsonb_build_object('ok',false,'code','not_found');end if;
   v_child:=v_part.child;
   if p_action='apply' and v_part.ack_response is null then
     begin
     select * into v_original from app_private.pos_catalog_import_recovery_uploads where shop_id=p_shop_id and shop_device_id=p_shop_device_id and upload_id=v_plan.original_id;
     if v_plan.mode='replacement' then
       if not exists(select 1 from app_private.pos_catalog_import_retirements where shop_id=p_shop_id and shop_device_id=p_shop_device_id
         and client_import_id=v_original.client_import_id and idempotency_key=v_original.idempotency_key and payload_hash=v_original.canonical_hash) then
         return v_binding||jsonb_build_object('status','conflict','reason','original_not_retired');end if;
       v_result:=public.pos_catalog_import_apply_v2(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
         v_child->>'clientImportId',v_child->>'idempotencyKey',v_child->>'payloadHash','pos-catalog-import-v1','supplier_excel',
         (v_child->>'createdAt')::timestamptz,v_child->'items',v_child->'summary','{}'::jsonb);
     else
       v_result:=public.pos_catalog_import_correct_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
         v_original.client_import_id,v_original.idempotency_key,v_original.canonical_hash,
         v_child->>'clientImportId',v_child->>'idempotencyKey',v_child->>'payloadHash',(v_child->>'createdAt')::timestamptz,v_child->'items');
     end if;
     if v_result->>'ok' is distinct from 'true' then raise exception 'Multipart apply rolled back' using errcode='P0941';end if;
     if v_result->>'status'='conflict' then v_result:=v_result||jsonb_build_object('planId',v_id,'partIndex',v_index,'parentStatus','partial');
       raise exception 'Multipart apply rolled back' using errcode='P0941';end if;
     -- Read the persisted ACK, not the altered duplicate summary returned by
     -- historical apply_v2. This same read verifies the complete identity tuple.
     v_result:=public.pos_catalog_import_receipt_v1(p_shop_id,p_shop_device_id,p_staff_id,p_pos_session_id,p_owner_user_id,
       v_child->>'clientImportId',v_child->>'idempotencyKey',v_child->>'payloadHash');
     if v_result->>'ok' is distinct from 'true' then raise exception 'Multipart late auth rolled back' using errcode='P0941';end if;
     if v_result->>'status' is distinct from 'accepted' or not app_private.pos_catalog_import_recovery_ack_valid_v1(
       case v_child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,v_child,v_result->'receipt') then
       raise exception 'Multipart ACK unavailable after apply' using errcode='23514';end if;
     v_receipt:=v_result->'receipt';
     update app_private.pos_catalog_import_recovery_plan_parts set ack_response=v_receipt,
       receipt_hash='sha256:'||encode(extensions.digest(v_receipt::text,'sha256'),'hex')
       where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id and part_index=v_index;
     exception when sqlstate 'P0941' then return v_result;end;
   else v_receipt:=v_part.ack_response;end if;
   if v_receipt is null then return v_binding||jsonb_build_object('status','conflict','reason','part_not_accepted');end if;
   if not app_private.pos_catalog_import_recovery_ack_valid_v1(
     case v_child->>'kind' when 'ordinary' then 'pos-catalog-import-v1' else 'pos-catalog-import-correction-v1' end,v_child,v_receipt) then
     return v_binding||jsonb_build_object('status','conflict','reason','receipt_unavailable');end if;
   select count(*)=v_plan.part_count into v_complete from app_private.pos_catalog_import_recovery_plan_parts
     where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id and ack_response is not null;
   v_result:=v_binding||jsonb_build_object('status','accepted','planId',v_id,'partIndex',v_index,
     'clientImportId',v_child->>'clientImportId','idempotencyKey',v_child->>'idempotencyKey','payloadHash',v_child->>'declaredPayloadHash',
     'canonicalPayloadHash',v_child->>'payloadHash','parentStatus',case when v_complete then 'complete' else 'partial' end,
     'partCount',v_plan.part_count,'acceptedPartCount',(select count(*) from app_private.pos_catalog_import_recovery_plan_parts
       where shop_id=p_shop_id and shop_device_id=p_shop_device_id and plan_id=v_id and ack_response is not null));
 end if;

 if v_receipt is not null then
   v_hash:='sha256:'||encode(extensions.digest(v_receipt::text,'sha256'),'hex');v_total:=jsonb_array_length(v_receipt->'items');
   if p_action='receipt-page' then
     v_offset:=(p_payload->>'offset')::integer;v_limit:=(p_payload->>'limit')::integer;
     if p_payload->>'receiptSha256' is distinct from v_hash or v_offset<0 or v_offset>=v_total or v_limit not between 1 and 1000 then
       return v_binding||jsonb_build_object('status','conflict','reason','receipt_cursor_conflict');end if;
   else v_offset:=0;v_limit:=least(1000,v_total);end if;
   v_expected:=(select coalesce(jsonb_agg(value order by ordinality),'[]'::jsonb) from jsonb_array_elements(v_receipt->'items') with ordinality
     where ordinality>v_offset and ordinality<=v_offset+v_limit);
   return (v_result-'receipt'-'currentProductSnapshots')||jsonb_build_object('receiptSha256',v_hash,'receiptEncoding','postgres-jsonb-text-v1',
     'totalItemCount',v_total,'offset',v_offset,'limit',v_limit,'complete',v_offset+v_limit>=v_total,
     'receipt',(v_receipt-'items'-'remoteProductIds'-'remotePriceIds')||jsonb_build_object('items',v_expected,
       'remoteProductIds',(select coalesce(jsonb_agg(mapping),'[]'::jsonb) from jsonb_array_elements(v_receipt->'remoteProductIds') mapping where exists(select 1 from jsonb_array_elements(v_expected) item where item->>'clientItemId'=mapping->>'clientItemId')),
       'remotePriceIds',(select coalesce(jsonb_agg(mapping),'[]'::jsonb) from jsonb_array_elements(v_receipt->'remotePriceIds') mapping where exists(select 1 from jsonb_array_elements(v_expected) item where item->>'clientItemId'=mapping->>'clientItemId'))),
     'currentProductSnapshots',(select coalesce(jsonb_agg(jsonb_build_object('clientItemId',item->>'clientItemId','remoteProductId',item->>'remoteProductId',
       'snapshotStatus',case when product.id is null then 'unavailable' else 'available' end,
       'baseRevision',case when product.id is null then null else to_char(product.updated_at at time zone 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') end,
       'retailPrice',product.retail_price,'purchasePrice',product.purchase_price,'stockQuantity',product.stock_quantity)),'[]'::jsonb)
       from jsonb_array_elements(v_expected) item left join public.inventory_products product on product.id::text=item->>'remoteProductId'
         and product.deleted_at is null and(product.shop_id=p_shop_id or(product.shop_id is null and product.owner_user_id=p_owner_user_id))));
 end if;
 return jsonb_build_object('ok',false,'code','validation_failed');
exception when invalid_text_representation or numeric_value_out_of_range or null_value_not_allowed then
 return jsonb_build_object('ok',false,'code','validation_failed');
end;
$$;
revoke all on function public.pos_catalog_import_recovery_v1(uuid,uuid,uuid,uuid,uuid,text,jsonb) from public,anon,authenticated;
grant execute on function public.pos_catalog_import_recovery_v1(uuid,uuid,uuid,uuid,uuid,text,jsonb) to service_role;
commit;
