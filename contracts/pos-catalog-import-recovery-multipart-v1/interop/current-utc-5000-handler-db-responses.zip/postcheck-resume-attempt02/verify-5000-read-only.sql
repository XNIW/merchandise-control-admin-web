select plan(15);
begin read only;
select is((select count(*)::integer from public.inventory_products),5000,'actual product table contains 5000 rows');
select is((select count(*)::integer from public.inventory_product_prices),10000,'actual price table contains 10000 rows');
select is((select count(*)::integer from public.inventory_products where stock_quantity=1.25),5000,'all real product stocks equal 1.25');
select is((select count(*)::integer from public.inventory_products where purchase_price=900 and retail_price=1200),5000,'all real product prices match unchanged C# intent');
select is((select count(*)::integer from public.inventory_products where product_name='Café 中文 '||replace(barcode,'INTEROP-','')),5000,'Unicode names survive actual handler and SQL writes');
select is((select count(*)::integer from public.pos_catalog_import_batches),5,'five actual ordinary batches');
select is((select count(*)::integer from public.pos_catalog_import_batches where status='accepted' and accepted_item_count=1000 and product_count=1000 and jsonb_array_length(ack_response->'remoteProductIds')=1000 and jsonb_array_length(ack_response->'remotePriceIds')=2000),5,'all five durable ACKs contain complete product and price maps');
select is((select count(distinct item->>'remoteProductId')::integer from public.pos_catalog_import_batches b cross join lateral jsonb_array_elements(b.ack_response->'remoteProductIds') item),5000,'5000 distinct actual product identities in persisted ACKs');
select is((select count(*)::integer from public.pos_catalog_import_batches b cross join lateral jsonb_array_elements(b.ack_response->'remoteProductIds') item join public.inventory_products p on p.id::text=item->>'remoteProductId' and p.barcode=item->>'barcode'),5000,'every product ACK map resolves to actual row and barcode');
select is((select count(distinct item->>'remotePriceId')::integer from public.pos_catalog_import_batches b cross join lateral jsonb_array_elements(b.ack_response->'remotePriceIds') item),10000,'10000 distinct actual price identities in persisted ACKs');
select is((select count(*)::integer from public.pos_catalog_import_batches b cross join lateral jsonb_array_elements(b.ack_response->'remotePriceIds') item join public.inventory_product_prices p on p.id::text=item->>'remotePriceId' and p.product_id::text=item->>'remoteProductId' and lower(p.type)=item->>'priceType'),10000,'every price ACK map resolves to actual price and product');
select is((select count(*)::integer from public.sync_events),10,'real ordinary apply wrote ten sync events');
select is((select count(*)::integer from public.audit_logs where event_key='pos.catalog.import_sync.success'),5,'real ordinary apply wrote five audits');
select is((select count(*)::integer from app_private.pos_catalog_import_retirements),0,'normal new 5000 plan has no retirement writes');
select is((select count(*)::integer from app_private.pos_catalog_import_corrections),0,'normal new 5000 plan has no correction writes');
select * from finish();
select jsonb_build_object('observedUTC',clock_timestamp(),'database',current_database(),'transactionReadOnly',current_setting('transaction_read_only'),
 'products',(select count(*) from public.inventory_products),'prices',(select count(*) from public.inventory_product_prices),
 'stockEach1_25',(select count(*) from public.inventory_products where stock_quantity=1.25),'batches',(select count(*) from public.pos_catalog_import_batches),
 'persistedProductMaps',(select sum(jsonb_array_length(ack_response->'remoteProductIds')) from public.pos_catalog_import_batches),
 'persistedPriceMaps',(select sum(jsonb_array_length(ack_response->'remotePriceIds')) from public.pos_catalog_import_batches),
 'syncEvents',(select count(*) from public.sync_events),'auditSuccess',(select count(*) from public.audit_logs where event_key='pos.catalog.import_sync.success'));
rollback;
